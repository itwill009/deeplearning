# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.

"""
import tensorflow as tf
import matplotlib.pyplot as plt
import numpy as np
import simple_loader as sl

before = 'e:/data/before.png'
after = 'e:/data/after.png'

before = sl.image_load(before)
after = sl.image_load(after)

X = tf.placeholder(tf.float32, [None, 250, 250, 1])
Y = tf.placeholder(tf.float32, [None, 250, 250, 1])


def auto(x,y):
    # 인코더 부분

    W1 = tf.Variable(tf.random_normal([5, 5, 1, 16], stddev=0.01))
    E1 = tf.nn.conv2d(x, W1, strides=[1, 2, 2, 1], padding='SAME')

    W2 = tf.Variable(tf.random_normal([5, 5, 16, 32], stddev=0.01))
    E2 = tf.nn.conv2d(E1, W2, strides=[1, 2, 2, 1], padding='SAME')

    W3 = tf.Variable(tf.random_normal([5, 5, 32, 64], stddev=0.01))
    ENCODER = tf.nn.conv2d(E2, W3, strides=[1, 2, 2, 1], padding='SAME')
    ENCODER = tf.nn.relu(ENCODER)
    # 디코더 부분

    W4 = tf.Variable(tf.random_normal([5, 5, 32, 64], stddev=0.01))
    D1 = tf.nn.conv2d_transpose(ENCODER, W4, [tf.shape(x)[0], 63, 63, 32], strides=[1, 2, 2, 1], padding='SAME')

    W5 = tf.Variable(tf.random_normal([5, 5, 16, 32], stddev=0.01))
    D2 = tf.nn.conv2d_transpose(D1, W5, [tf.shape(x)[0], 125, 125, 16], strides=[1, 2, 2, 1], padding='SAME')

    W6 = tf.Variable(tf.random_normal([5, 5, 1, 16], stddev=0.01))
    DECODER = tf.nn.conv2d_transpose(D2, W6, [tf.shape(x)[0], 250, 250, 1], strides=[1, 2, 2, 1], padding='SAME')
    
        
    cost = tf.reduce_mean(tf.square(tf.subtract(DECODER, y)))

    return DECODER, cost


# 디코더는 인풋과 최대한 같은 결과를 내야 하므로, 디코딩한 결과를 평가하기 위해
# 입력 값인 X 값을 평가를 위한 실측 결과 값으로하여 decoder 와의 차이를 손실값으로 설정합니다.

conv_auto = auto(X,Y)
pred, cost = conv_auto

training_epoch = 10
#batch_size = 100

optimizer = tf.train.AdamOptimizer().minimize(cost)

########
# 신경망 모델 학습
#####
init = tf.global_variables_initializer()
sess = tf.Session()
sess.run(init)

mean_img=np.zeros((784))
#total_batch = int(mnist.train.num_examples / batch_size)
total_batch=500

for epoch in range(training_epoch):
    total_cost = 0

    for i in range(total_batch):
#        batch_xs, _ = mnist.train.next_batch(batch_size)
#        trainbatch = np.array([img- mean_img for img in batch_xs])
#        trainbatch_noisy = trainbatch+0.5*np.random.randn(trainbatch.shape[0],784)
        _, cost_val = sess.run([optimizer, cost], feed_dict={X: before.reshape(-1,250,250,1), Y:after.reshape(-1,250,250,1)})
        total_cost += cost_val

    print('Epoch:', '%04d' % (epoch + 1),
          'Avg. cost =', '{:.4f}'.format(total_cost / total_batch))

print('최적화 완료!')

#########
# 결과 확인
# 입력값(위쪽)과 모델이 생성한 값(아래쪽)을 시각적으로 비교해봅니다.
#####
sample_size = 1
#mnist_test=mnist.test.images[:sample_size]
#mnist_test = mnist_test + 0.5*np.random.randn(mnist_test.shape[0], 784)
#mnist_test=mnist_test.reshape(-1,28,28,1)
samples = sess.run(pred, feed_dict={X: before.reshape(-1,250,250,1)})

#fig, ax = plt.subplots(2, sample_size, figsize=(sample_size, 2))
#
#for i in range(sample_size):
#   ax[0][i].set_axis_off()
#   ax[1][i].set_axis_off()
#   ax[0][i].imshow(np.reshape(before, (250, 250)))
#   ax[1][i].imshow(np.reshape(samples,(250, 250)))

a=samples.reshape(250,250)
#print(a)
plt.imshow(a,cmap='gray')
plt.show()
