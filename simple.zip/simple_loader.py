# -*- coding: utf-8 -*-
"""
Created on Tue Feb 20 21:26:32 2018

@author: 마이마이
"""

import os

import numpy as np
import matplotlib.pyplot as plt

import cv2

def image_load(path):
    
    
    img = cv2.imread(path,0)
    #img = np.array(img)
    #print(img.shape)
    img = cv2.resize(img,(250,250))
     
    
    return np.array(img)






